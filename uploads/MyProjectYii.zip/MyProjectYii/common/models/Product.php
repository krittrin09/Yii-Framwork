<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "product".
 *
 * @property int $id
 * @property string $name
 * @property string $ingredients
 * @property string $cooking_methods
 * @property string|null $food
 * @property string|null $dessert
 * @property string|null $drinking
 * @property string $img_path
 */
class Product extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'product';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'ingredients', 'cooking_methods'], 'required'],
            [['ingredients', 'cooking_methods', 'food', 'dessert', 'drinking'], 'string'],
            [['name', 'img_path'], 'string', 'max' => 200],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'ingredients' => 'Ingredients',
            'cooking_methods' => 'Cooking Methods',
            'food' => 'Food',
            'dessert' => 'Dessert',
            'drinking' => 'Drinking',
            'img_path' => 'Img Path',
        ];
    }
}

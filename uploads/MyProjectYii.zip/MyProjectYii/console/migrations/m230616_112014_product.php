<?php

use yii\db\Migration;

/**
 * Class m230616_112014_product
 */
class m230616_112014_product extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $tableOptions = null;
        if ($this->db->driverName === 'mysql') {
            // http://stackoverflow.com/questions/766809/whats-the-difference-between-utf8-general-ci-and-utf8-unicode-ci
            $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';
        }

        $this->createTable('{{%product}}', [
            'id' => $this->primaryKey(),
            'name' => $this->string(200)->notNull(),
            'ingredients' => $this->text()->notNull(),
            'cooking_methods' => $this->text()->notNull(),
            'food' => "ENUM('Thai','America','Japan','Chaina','India','Korea')",
            'dessert' => "ENUM('Cake','Bread','Pie')",
            'drinking' => "ENUM('Soda','Juice','Alcolhol','Tea','Milk')",
            'img_path' => $this->string(200)->notNull()->defaultValue('img/FOOD.png'),
            

        ], $tableOptions);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m230616_112014_product cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m230616_112014_product cannot be reverted.\n";

        return false;
    }
    */
}
